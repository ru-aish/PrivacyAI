import { createBrowserClient, localSanitize } from "@privacy-ai/sdk/browser";
import { getEffectiveConfig, hasRemoteProvider, PROVIDER_PRESETS } from "./config.js";
import { isSupportedChatUrl } from "./supported-sites.js";


let privateClient = null;

console.log("PrivacyAI background service worker loaded");

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tabId && isSupportedChatUrl(tab.url)) {
    injectPageBridge(tabId).catch(() => {});
  }
});

chrome.runtime.onInstalled.addListener(async () => {
  const data = await chrome.storage.local.get(["provider", "baseUrl"]);
  if (!data.provider && !data.baseUrl) {
    await chrome.storage.local.set({
      shieldEnabled: true,
      ...PROVIDER_PRESETS.ollama
    });
    console.log("PrivacyAI: seeded default Ollama provider config");
  }
});

async function getStoredConfig() {
  return chrome.storage.local.get(["provider", "model", "baseUrl", "apiKey"]);
}

async function getClient() {
  if (!privateClient) {
    const data = await getStoredConfig();
    const config = getEffectiveConfig(data);

    privateClient = createBrowserClient({
      provider: config.provider,
      model: config.model,
      baseURL: config.baseUrl,
      apiKey: config.apiKey
    });
  }
  return privateClient;
}

async function sanitizeText(text) {
  const stored = await getStoredConfig();
  const config = getEffectiveConfig(stored);

  if (!hasRemoteProvider(stored)) {
    console.log("PrivacyAI: no provider configured, using local regex sanitization");
    return localSanitize(text);
  }

  try {
    const client = await getClient();
    console.log("PrivacyAI: sanitizing via API", {
      provider: config.provider,
      baseUrl: config.baseUrl,
      model: config.model
    });
    return await client.sanitize(text);
  } catch (error) {
    console.error("Sanitization error details:", error, error.details || error.message);
    console.log("PrivacyAI: API failed, falling back to local regex sanitization");
    return localSanitize(text);
  }
}

async function injectPageBridge(tabId) {
  if (!tabId) return false;

  const tab = await chrome.tabs.get(tabId);
  if (!isSupportedChatUrl(tab.url)) return false;

  await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    world: "MAIN",
    files: ["page-bridge-main.js"]
  });

  return true;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "inject-page-bridge") {
    (async () => {
      try {
        const success = await injectPageBridge(sender.tab?.id);
        sendResponse({ success });
      } catch (error) {
        console.error("PrivacyAI page bridge injection failed:", error);
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true;
  }

  if (request.action === "ping") {
    sendResponse({ success: true, message: "PrivacyAI background is running" });
    return false;
  }

  if (request.action === "sanitize") {
    console.log("PrivacyAI: received sanitize request", {
      length: request.text?.length,
      from: sender.tab?.url || "unknown"
    });

    (async () => {
      try {
        const result = await sanitizeText(request.text);
        console.log("PrivacyAI: sanitize complete", {
          source: result.privacySource || "local-regex",
          preview: result.sanitizedText?.slice(0, 80)
        });

        sendResponse({ success: true, result });
      } catch (error) {
        console.error("PrivacyAI sanitization failed:", error);
        sendResponse({ success: false, error: error.message, details: error.details });
      }
    })();
    return true;
  }

  if (request.action === "updateConfig") {
    privateClient = null;
    sendResponse({ success: true });
    return false;
  }

  if (request.action === "testConnection") {
    (async () => {
      try {
        const client = await getClient();
        const response = await client.provider.chat({
          messages: [{ role: "user", content: "Reply with exactly: OK" }],
          maxTokens: 10,
          temperature: 0
        });

        if (response && response.text) {
          sendResponse({ success: true, message: `Connected successfully! Response: ${response.text.trim()}` });
        } else {
          sendResponse({ success: false, error: "Empty response from model" });
        }
      } catch (error) {
        console.error("Test connection failed:", error);
        sendResponse({ success: false, error: error.message || String(error) });
      }
    })();
    return true;
  }
});